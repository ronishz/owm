import socket
import hashlib
import os

c1=socket.socket()
c1.connect(("localhost",12345))
print "1.Text\n2.Image\n"
choice=raw_input()
c1.send(choice)
choice=int(choice)

data1=c1.recv(1024)
print data1

size=data1.split('--')[0]
data=data1.split('--')[1]

print "Size-",size
print "Data-",data
bytes=int(size)
bytes=bytes-len(data)

while(int(size)>len(data)):
	if(bytes<1024 and bytes>0):
		data=data+c1.recv(bytes)
		bytes=0
		break
	else:
		data=data+c1.recv(1024)
		bytes=bytes-1024
	print "bytes- ",bytes
	
#print "Complete Data- ",data
prev_hash=c1.recv(40)
print "prev_hash -",prev_hash

if(choice==1):
	f1=open('new.cpp','w')
	f1.write(data)
	print "Data before writing- ",data
	print len(data)
	f1.close()
	f2=open('new.cpp','r')
	data=f2.read(int(os.path.getsize('new.cpp')))
	print "Data after writing- ",data
elif(choice==2):
	f1=open('image.png','w')
	f1.write(str(data))
	print len(data)
	f1.close()
	f2=open('image.png','r')
	data=f2.read(int(os.path.getsize('image.png')))	

h=hashlib.sha1(data).hexdigest()
print "Hash-",h
if(h==prev_hash):
	print "No tamper"
else:
	print "tamper"	





