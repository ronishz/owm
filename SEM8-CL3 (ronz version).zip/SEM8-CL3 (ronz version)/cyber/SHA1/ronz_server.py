import socket
import os 
import hashlib
import time as t

s=socket.socket()
s.bind(("localhost",12345))
s.listen(5)

c,addr=s.accept()

while True:
	print "client connected at ",addr
	choice=int(c.recv(2))
	if(choice==1):
		print "Sending Text file"
		f=open('a.cpp','r')
		size=os.path.getsize('a.cpp')
		data=f.read(size)

		h=hashlib.sha1(data).hexdigest()
		print h
		c.send(str(size)+"--"+data)
		t.sleep(2)
		c.send(h)

	elif(choice==2):
		print "Sending Image file"
		f=open('b.png')
		size=os.path.getsize('b.png')
		print str(size)
		data=f.read(size)
		h=hashlib.sha1(data).hexdigest()
		print h
		c.send(str(size)+"--"+data)
		t.sleep(2)
		c.send(h)
	
	c.close()	