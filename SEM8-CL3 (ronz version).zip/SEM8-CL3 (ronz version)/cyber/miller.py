import random

n=int(raw_input("Enter number\n"))
q=n-1
k=0
loops=100

while q%2==0:
	q=q/2
	k+=1

print "n=(2^k)*q"
print "q- ",q
print "k- ",k
print "n- ",n

def miller(n,q,k):
	a=random.randint(2,n-1)
	x=pow(a,q,n)
	if(x==1 or x==n-1):
		return 1 #probably prime

	for j in range(0,k):
		x=pow(x,2,n)
		if(x==1):
			return 0 #not prime
		elif(x==n-1):
			return 1 #prime

yes=0
no=0
temp=0
for i in range(0,loops):
	temp=miller(n,q,k)
	if(temp==1):
		yes+=1
	else:
		no+=1

print "probability of prime- ",float(yes)/loops
print "probability of not prime- ",float(no)/loops			

