from pyDes import des
import numpy as np


def CC(msg):
	msg=list(msg)
	for i in range(0,len(msg)):
		msg[i]=ord(msg[i])+3

	e=""

	for i in range(0,len(msg)):
		e+=chr(msg[i])

	print e

def Hill(msg):
	key=[[10,2,1],[5,9,7],[11,7,4]] #KCB FJH LHE
	text = []
	Slist = []
	e = []

	msg=list(msg)

	for i in range(0,len(msg)):
		text.append(ord(msg[i])-65)

	while(len(text)%3!=0):
		text.append(25)	

	for i in range(0,len(text),3):
		Slist.append(text[i:i+3])

	for element in Slist:
		temp=(np.dot(key,element)%26).tolist()
		e.append(temp)

	print e
	e1 = ""
	for i in range(0,len(e)):
		for j in range(0,3):
			e1+=chr(e[i][j]+65)
	print e1				



def Des(msg):
	k=des('MITPUNEE',pad='Z')
	e=k.encrypt(msg)
	d=k.decrypt(e)

	print e
	print d 


msg=raw_input('Enter msg\n')
ch=int(raw_input("1.Des\n2.Hill Cipher\n3.Caesar cipher\n"))

if(ch==1):
	Des(msg)
elif(ch==2):
	Hill(msg)
elif(ch==3):
	CC(msg)


