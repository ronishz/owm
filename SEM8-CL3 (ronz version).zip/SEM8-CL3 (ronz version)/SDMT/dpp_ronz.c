#include <semaphore.h>
#include <stdio.h>
#include <pthread.h>

#define n 5
#define LEFT (ph_num+4)%n
#define RIGHT (ph_num+1)%n
#define THINKING 0
#define EATING 2
#define HUNGRY 1

sem_t mutex;
sem_t S[n];

void *philosopher(void *num);
void take_fork(int);
void put_fork(int);
void test(int);

int state[n];
int phil_num[n]={0,1,2,3,4};

int main()
{
	int i;
	pthread_t thread_id[n];

	sem_init(&mutex,0,1);

	for(i=0;i<n;i++)
		sem_init(&S[i],0,0);

	for(i=0;i<n;i++)
	{
		pthread_create(&thread_id[i],NULL,philosopher,&phil_num[i]);
		printf("philosopher %d is thinking\n",i+1);
	}

	for(i=0;i<n;i++)
	{
		pthread_join(thread_id[i],NULL);
	}

}

void *philosopher(void *num)
{
	while(1)
	{
		int *i=num;
		sleep(1);
		take_fork(*i);
		sleep(0);
		put_fork(*i);
	}
}

void take_fork(int ph_num)
{
	sem_wait(&mutex);
	state[ph_num]=HUNGRY;
	printf("philosopher %d is Hungry\n",ph_num+1);
	test(ph_num);
	sem_post(&mutex);
    sem_wait(&S[ph_num]);
	sleep(1);

}

void test(int ph_num)
{
	if(state[ph_num]==HUNGRY && state[LEFT]!= EATING && state[RIGHT]!=EATING)
	{
		state[ph_num]=EATING;
		sleep(2);
		printf("philosopher %d takes fork %d and %d\n",ph_num+1,LEFT+1,ph_num+1 );
		printf("philosopher %d is EATING\n",ph_num+1 );
		sem_post(&S[ph_num]);

	}
}

void put_fork(int ph_num)
{
	sem_wait(&mutex);
	state[ph_num]=THINKING;
	printf("philosopher %d puts fork %d and %ddown\n",ph_num+1,LEFT+1,ph_num+1 );
	printf("philosopher %d is THINKING\n",ph_num+1 );
	test(LEFT);
	test(RIGHT);
	sem_post(&mutex);

}
