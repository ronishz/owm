import copy
from flask import Flask,render_template,request
app=Flask(__name__)

@app.route('/')
def main():
	return render_template('booth.html')

@app.route('/',methods=["POST"])
def response():
	n1=int(request.form['num1'])
	n2=int(request.form['num2'])
	return str(boothsmultiplication(DecimalTobinary(n1),DecimalTobinary(n2)))


def twoCom(arr):
	flag=False
	for i in range(0,len(arr)):
		if(flag!=True and arr[i]==1):
			flag=True
		elif(flag==True):
			if(arr[i]==1):
				arr[i]=0
			else:
				arr[i]=1

	return arr


def DecimalTobinary(num):
	length=16
	arr = []
	neg=False
	if(num<0):
		neg=True
		num=-1*num

	for i in range(0,length):
		arr.append(num%2)
		num=num/2

	if(neg):
		arr=twoCom(arr)
	
	return arr


def binaryToDecimal(arr):
	result=0
	length = len(arr)
	neg=False
	if(arr[-1]==1):
		neg=True


	if(neg):
		arr=twoCom(arr)

	for i in range(0,length):
		result=result+ arr[i]*pow(2,i)

	if(neg):
		result=result*-1
	
	return result



def Addition(n1,n2):
	binaryResult=[]
	carry=0

	for i in range(0,16):
		if(n1[i]==0 and n2[i]==0 and carry==0):
			binaryResult.append(0)
			carry=0
		elif(n1[i]==0 and n2[i]==0 and carry==1):
			binaryResult.append(1)
			carry=0
		elif(n1[i]==0 and n2[i]==1 and carry==0):
			binaryResult.append(1)
			carry=0
		elif(n1[i]==0 and n2[i]==1 and carry==1):
			binaryResult.append(0)
			carry=1
		elif(n1[i]==1 and n2[i]==0 and carry==0):
			binaryResult.append(1)
			carry=0
		elif(n1[i]==1 and n2[i]==0 and carry==1):
			binaryResult.append(0)
			carry=1
		elif(n1[i]==1 and n2[i]==1 and carry==0):
			binaryResult.append(0)
			carry=1
		elif(n1[i]==1 and n2[i]==1 and carry==1):
			binaryResult.append(1)
			carry=1

	return binaryResult		


def Subtraction(n1,n2):
	temp = copy.deepcopy(n2)
	return Addition(n1,twoCom(n2)),temp		

def asr(A,Q,Q_1):
	Q_0=A[0]
	Q_1=Q[0]

	A=A[::-1]
	Q=Q[::-1]

	for i in range(len(A)-1,0,-1):
		A[i]=A[i-1]
		Q[i]=Q[i-1]

	Q[0]=Q_0
	
	A=A[::-1]
	Q=Q[::-1]
	print Q
	return A,Q,Q_1	





def boothsmultiplication(num1,num2):
	A=[0]*16
	Q_1=0

	M=copy.deepcopy(num1)
	Q=copy.deepcopy(num2)
	print("A : ",A[::-1])
	print("M : ",M[::-1])
	print("Q : ",Q[::-1])

	for i in range(0,len(Q)):
		if(Q[0]==0 and Q_1==1):
			A=Addition(A,M)
		elif(Q[0]==1 and Q_1==0):
			A,M=Subtraction(A,M)

		print("A : ",A[::-1])
		print("M : ",M[::-1])
		print("Q : ",Q[::-1])	

		A,Q,Q_1=asr(A,Q,Q_1)

		print("A : ",A[::-1])
		print("M : ",M[::-1])
		print("Q : ",Q[::-1])

	return binaryToDecimal(Q+A)	




if __name__=="__main__":
	app.debug=True
	app.run()
#print DecimalTobinary(n1)[::-1]
#print DecimalTobinary(n2)[::-1]
'''
print DecimalTobinary(binaryToDecimal(n1))
print DecimalTobinary(binaryToDecimal(n2))
'''
#print(boothsmultiplication(DecimalTobinary(n1),DecimalTobinary(n2)))

#print asr(DecimalTobinary(n1),DecimalTobinary(n2),1)