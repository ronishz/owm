#include <iostream>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <omp.h>
#include <unistd.h>
using namespace std;


class Binary{
	int a[100],key,high,low;
public:
	void getdata();
	int b_r(int *a,int key,int low,int high);
	void b_nr(int *a,int key,int low,int high);
}; 

int Binary::b_r(int *a,int key,int low,int high)
{
	int mid=(low+high)/2;
	if(key==a[mid])
	{
		cout<<"Key found at- "<<mid+1<<"\n";
		return 0;
	}
	else if(key>a[mid])
	{
		low=mid+1;
	}
	else if(key<a[mid])
	{
		high=mid-1;
	}

	if(low>high)
	{
		cout<<"key not found";
		return 0;
	}

	b_r(a,key,low,high);

}

void Binary::b_nr(int *a,int key,int low,int high)
{

	int mid;

	while(low<high)
	{	
		mid=(low+high)/2;
		if(key==a[mid])
		{
			cout<<"Key found at- "<<mid+1<<"\n";
			return;
		}
		else if(key>a[mid])
		{
			low=mid+1;
		}
		else if(key<a[mid])
		{
			high=mid-1;
		}

	}
	cout<<"Key not found";

}

void Binary::getdata()
{
	int n,ch,key;
	cout<<"Enter no of elements\n";
	cin>>n;
	double start,end;

	for(int i=0;i<n;i++)
	{
		a[i]=rand()%100;
	}

	cout<<"Un sorted array\n";
	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}

	sort(a,a+n);

	cout<<"Sorted array\n";

	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}

	low=0;
	high=n-1;
	
	cout<<"Key?\n";
	cin>>key;

	cout<<"1.Recursive\n2.Non-Recursive\n";
	cin>>ch;
	if(ch==1)
	{
		start=omp_get_wtime();
		b_r(a,key,low,high);
		end=omp_get_wtime();
	}
	else if(ch==2)
	{
		start=omp_get_wtime();
		b_nr(a,key,low,high);
		end=omp_get_wtime();
	}
	else{
		cout<<"Wrong choice";
	}

	cout<<"Time: "<<end-start<<"\n";


}

int main()
{
	Binary b;
	b.getdata();
	return 0;
}

