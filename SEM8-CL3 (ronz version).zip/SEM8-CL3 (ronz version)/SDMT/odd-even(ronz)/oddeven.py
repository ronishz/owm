from flask import Flask,render_template,request
import threading
from threading import Thread
from multiprocessing.pool import ThreadPool
import time

app=Flask(__name__)

@app.route('/')
def main():
	return render_template("oddeven.html")

@app.route('/',methods=['POST'])

def my_form_post():
	no_elements=request.form['no_elements']
	elements=request.form['elements']
	array=oddeven(elements)
	return (str(array))

def oddeven(elements):
	elements=list(map(int,elements.split(',')))
	s=False
	lthread = None
	rthread = None

	while(not(s)):
		pool=ThreadPool(processes=1)

		thread1=pool.apply_async(innersort,(elements,1))
		thread2=pool.apply_async(innersort,(elements,0))

		s=thread1.get()
		s=thread2.get() and s

	return elements

def innersort(arr,val):
	s=True

	for i in range(val,len(arr)-1,2):
		if(arr[i]>arr[i+1]):
			temp=arr[i]
			arr[i]=arr[i+1]
			arr[i+1]=temp
			s=False
	return s					

if __name__ == "__main__":
	app.debug = True
	app.run() 
