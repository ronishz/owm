#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
using namespace std;



class Quick{
	int a[100],start,end;
public:
	int partition(int *a,int start,int end);
	void quicksort(int *a,int start,int end);
};


int Quick::partition(int *a,int start,int end)
{
	int i=start;
	int temp;
	int pivot=a[end];

	for(int j=start;j<end;j++)
	{
		if(a[j]<=pivot)
		{
			temp=a[j];
			a[j]=a[i];
			a[i]=temp;
			i+=1;
		}
	}

	temp=a[i];
	a[i]=a[end];
	a[end]=temp;

	return i;




}

void Quick::quicksort(int *a,int start,int end)
{
	int p;
	if(start<end)
	{
		omp_set_nested(1);
		omp_set_num_threads(20);

		#pragma omp parallel sections
		{
			p=partition(a,start,end);
			#pragma omp section
			{
				quicksort(a,start,p-1);
			}

			#pragma omp section
			{
				quicksort(a,p+1,end);	
			}

		}
		
	}
}




int main()
{
	int n,a[100];
	cout<<"Enter number of elements\n";
	cin>>n;

	Quick q;

	for(int i=0;i<n;i++)
	{
		a[i]=rand()%100;
	}

	cout<<"Unsorted array- ";

	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}
	cout<<"\n";

	q.quicksort(a,0,n-1);

	cout<<"\nSorted data-\n";

	for(int i=0;i<n;i++)
	{
		cout<<a[i]<<" ";
	}
	cout<<"\n";
	
	return 0;
} 
